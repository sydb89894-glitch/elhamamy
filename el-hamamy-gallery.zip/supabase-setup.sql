-- شغّل الملف كله في Supabase > SQL Editor (آمن لو اتشغل قبل كده)
create table if not exists products(id text primary key,title text,price text,old_price text,dim text,cat text,badge text,description text,img_url text,created_at timestamptz default now());
create table if not exists reviews(id uuid primary key default gen_random_uuid(),name text,text text,img_url text,created_at timestamptz default now());
create table if not exists materials(id uuid primary key default gen_random_uuid(),name text,text text,created_at timestamptz default now());
alter table products add column if not exists images text[] default '{}';
alter table products add column if not exists video_url text;
do $$ declare t text; begin foreach t in array array['products','reviews','materials'] loop
 execute format('alter table %I enable row level security',t);
 execute format('drop policy if exists "read %1$s" on %1$I',t);
 execute format('drop policy if exists "write %1$s" on %1$I',t);
 execute format('create policy "read %1$s" on %1$I for select using (true)',t);
 execute format('create policy "write %1$s" on %1$I for all to authenticated using ((auth.jwt()->>''email'')=''sydb89894@gmail.com'') with check ((auth.jwt()->>''email'')=''sydb89894@gmail.com'')',t);
end loop; end $$;
insert into storage.buckets(id,name,public) values('products','products',true) on conflict (id) do nothing;
drop policy if exists "public read files" on storage.objects;
drop policy if exists "admin upload files" on storage.objects;
drop policy if exists "admin delete files" on storage.objects;
create policy "public read files" on storage.objects for select using (bucket_id='products');
create policy "admin upload files" on storage.objects for insert to authenticated with check (bucket_id='products' and (auth.jwt()->>'email')='sydb89894@gmail.com');
create policy "admin delete files" on storage.objects for delete to authenticated using (bucket_id='products' and (auth.jwt()->>'email')='sydb89894@gmail.com');
do $$ begin alter publication supabase_realtime add table products, reviews, materials; exception when others then null; end $$;

-- ===== البحث بالصور (pgvector) =====
create extension if not exists vector;
alter table products add column if not exists embedding vector(512);
create or replace function search_similar_furniture(query_embedding vector(512), min_similarity float, max_results int)
returns table(id text, similarity float) language sql stable as $$
  select p.id, (1 - (p.embedding <=> query_embedding))::float as similarity
  from products p
  where p.embedding is not null and 1 - (p.embedding <=> query_embedding) >= min_similarity
  order by p.embedding <=> query_embedding limit max_results $$;
-- السماح للزوار برفع صورة البحث في مجلد searches فقط
drop policy if exists "anon upload searches" on storage.objects;
create policy "anon upload searches" on storage.objects for insert to anon, authenticated with check (bucket_id='products' and name like 'searches/%');
